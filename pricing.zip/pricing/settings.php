<?php
	define('HOST', 'localhost');

	define('USERNAME', 'root');

	define('PASSWORD', 'b2baalgro_mysql');

	define('DB', 'aalgro_store');
?>